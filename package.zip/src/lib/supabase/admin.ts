﻿import "server-only";
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/lib/db-types";
import { getEnv } from "@/lib/env";

export function createAdminSupabase() {
  const env = getEnv();
  return createClient<Database>(
    env.NEXT_PUBLIC_SUPABASE_URL,
    env.SUPABASE_SERVICE_ROLE_KEY,
    { auth: { persistSession: false, autoRefreshToken: false } },
  );
}


