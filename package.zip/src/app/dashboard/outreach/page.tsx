﻿"use client";

import { useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";

type OutreachResult = {
  email: { subject: string; body: string; cta: string };
  linkedin_dm: string;
  follow_up_day3: string;
  follow_up_day7: string;
  personalization_score: number;
  why_this_works: string;
};

const tones = ["Professional", "Casual", "Direct"] as const;
const tabs = ["Cold Email", "LinkedIn DM", "Follow-up Day 3", "Breakup Day 7"] as const;

const toneConfig = {
  Professional: { color: "from-cyan-500 to-blue-500", glow: "shadow-cyan-500/20", border: "border-cyan-500/30", bg: "bg-cyan-500/10" },
  Casual: { color: "from-violet-500 to-purple-500", glow: "shadow-violet-500/20", border: "border-violet-500/30", bg: "bg-violet-500/10" },
  Direct: { color: "from-emerald-500 to-teal-500", glow: "shadow-emerald-500/20", border: "border-emerald-500/30", bg: "bg-emerald-500/10" },
};

const tabIcons: Record<string, string> = {
  "Cold Email": "✉",
  "LinkedIn DM": "💼",
  "Follow-up Day 3": "🔁",
  "Breakup Day 7": "👋",
};

export default function OutreachPage() {
  const params = useSearchParams();
  const [companyName, setCompanyName] = useState(params.get("company") ?? "");
  const [painPoints, setPainPoints] = useState(params.get("pains") ?? "");
  const [outreachAngle, setOutreachAngle] = useState(params.get("angle") ?? "");
  const [productName, setProductName] = useState("");
  const [productDescription, setProductDescription] = useState("");
  const [tone, setTone] = useState<(typeof tones)[number]>("Professional");
  const [result, setResult] = useState<OutreachResult | null>(null);
  const [tab, setTab] = useState<(typeof tabs)[number]>("Cold Email");
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [whyOpen, setWhyOpen] = useState(false);

  const currentContent = useMemo(() => {
    if (!result) return "";
    if (tab === "Cold Email") return `Subject: ${result.email.subject}\n\n${result.email.body}\n\nCTA: ${result.email.cta}`;
    if (tab === "LinkedIn DM") return result.linkedin_dm;
    if (tab === "Follow-up Day 3") return result.follow_up_day3;
    return result.follow_up_day7;
  }, [result, tab]);

  async function generate(selectedTone: (typeof tones)[number]) {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/outreach", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ companyName, painPoints, outreachAngle, productName, productDescription, tone: selectedTone }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Failed to generate outreach");
      setResult(data);
      setTone(selectedTone);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to generate outreach");
    } finally {
      setLoading(false);
    }
  }

  async function handleCopy() {
    await navigator.clipboard.writeText(currentContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  const scoreColor = (s: number) => s >= 80 ? "text-emerald-400" : s >= 60 ? "text-amber-400" : "text-red-400";
  const scoreGradient = (s: number) => s >= 80 ? "from-emerald-500 to-teal-500" : s >= 60 ? "from-amber-500 to-orange-500" : "from-red-500 to-pink-500";

  return (
    <div className="min-h-screen" style={{ background: "linear-gradient(135deg, #050816 0%, #07111f 50%, #0b1020 100%)" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap');
        .page-font { font-family: 'DM Sans', sans-serif; }
        .heading-font { font-family: 'Syne', sans-serif; }
        .glass { background: rgba(255,255,255,0.03); backdrop-filter: blur(20px); border: 1px solid rgba(255,255,255,0.08); }
        .glass-hover { transition: all 0.3s ease; }
        .glass-hover:hover { background: rgba(255,255,255,0.06); border-color: rgba(255,255,255,0.12); }
        .glow-cyan { box-shadow: 0 0 30px rgba(6,182,212,0.15), 0 0 60px rgba(6,182,212,0.05); }
        .input-field { background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.1); border-radius: 12px; padding: 12px 16px; color: #e2e8f0; font-size: 14px; width: 100%; outline: none; transition: all 0.2s; font-family: 'DM Sans', sans-serif; }
        .input-field::placeholder { color: rgba(148,163,184,0.5); }
        .input-field:focus { border-color: rgba(6,182,212,0.5); background: rgba(6,182,212,0.05); box-shadow: 0 0 0 3px rgba(6,182,212,0.08); }
        .btn-primary { background: linear-gradient(135deg, #06b6d4, #3b82f6); border: none; border-radius: 12px; padding: 12px 24px; color: white; font-weight: 600; cursor: pointer; font-size: 14px; transition: all 0.2s; font-family: 'DM Sans', sans-serif; }
        .btn-primary:hover:not(:disabled) { transform: translateY(-1px); box-shadow: 0 8px 24px rgba(6,182,212,0.3); }
        .btn-primary:disabled { opacity: 0.5; cursor: not-allowed; }
        .btn-ghost { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 10px; padding: 10px 18px; color: #94a3b8; font-size: 13px; cursor: pointer; transition: all 0.2s; font-family: 'DM Sans', sans-serif; }
        .btn-ghost:hover:not(:disabled) { background: rgba(255,255,255,0.09); color: #e2e8f0; }
        .btn-ghost:disabled { opacity: 0.4; cursor: not-allowed; }
        .score-ring { position: relative; display: flex; align-items: center; justify-content: center; }
        .tab-active { background: rgba(6,182,212,0.15); border: 1px solid rgba(6,182,212,0.35); color: #22d3ee; }
        .tab-inactive { background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); color: #64748b; }
        .tab-inactive:hover { background: rgba(255,255,255,0.06); color: #94a3b8; }
        .sent-badge { background: linear-gradient(135deg, #10b981, #059669); }
        .unsent-badge { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); }
        .loading-shimmer { background: linear-gradient(90deg, rgba(255,255,255,0.05) 25%, rgba(255,255,255,0.1) 50%, rgba(255,255,255,0.05) 75%); background-size: 200% 100%; animation: shimmer 1.5s infinite; }
        @keyframes shimmer { 0% { background-position: 200% 0; } 100% { background-position: -200% 0; } }
        @keyframes fadeInUp { from { opacity:0; transform:translateY(16px); } to { opacity:1; transform:translateY(0); } }
        .fade-in { animation: fadeInUp 0.4s ease forwards; }
        .pulse-dot { width: 8px; height: 8px; border-radius: 50%; background: #22d3ee; animation: pulse 2s infinite; }
        @keyframes pulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:0.5;transform:scale(0.8)} }
        .grid-bg { background-image: linear-gradient(rgba(6,182,212,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(6,182,212,0.04) 1px, transparent 1px); background-size: 48px 48px; }
      `}</style>

      <div className="page-font grid-bg min-h-screen">
        <div className="max-w-5xl mx-auto px-6 py-8">

          {/* Header */}
          <div className="mb-8 fade-in">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-xs font-bold">AI</div>
              <span className="text-xs font-medium text-cyan-400/70 uppercase tracking-widest">Outreach Engine</span>
              <div className="pulse-dot ml-1" />
            </div>
            <h1 className="heading-font text-3xl font-bold text-white mb-1">AI Outreach Generator</h1>
            <p className="text-slate-400 text-sm">Personalized sequences engineered to convert. Every message built on signal intelligence.</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">

            {/* Left: Input Form */}
            <div className="lg:col-span-2 space-y-4 fade-in" style={{ animationDelay: "0.05s" }}>
              <div className="glass rounded-2xl p-6 space-y-4">
                <h2 className="heading-font text-base font-semibold text-white">Target Intelligence</h2>

                <div>
                  <label className="text-xs text-slate-500 uppercase tracking-wide mb-2 block">Company Name</label>
                  <input className="input-field" value={companyName} onChange={(e) => setCompanyName(e.target.value)} placeholder="Acme Corp" />
                </div>
                <div>
                  <label className="text-xs text-slate-500 uppercase tracking-wide mb-2 block">Their Pain Points</label>
                  <input className="input-field" value={painPoints} onChange={(e) => setPainPoints(e.target.value)} placeholder="e.g. losing leads to competitors" />
                </div>
                <div>
                  <label className="text-xs text-slate-500 uppercase tracking-wide mb-2 block">Outreach Angle</label>
                  <input className="input-field" value={outreachAngle} onChange={(e) => setOutreachAngle(e.target.value)} placeholder="e.g. they ranked #3 last month" />
                </div>

                <div className="h-px bg-white/5" />

                <div>
                  <label className="text-xs text-slate-500 uppercase tracking-wide mb-2 block">Your Product</label>
                  <input className="input-field" value={productName} onChange={(e) => setProductName(e.target.value)} placeholder="Product name" />
                </div>
                <div>
                  <label className="text-xs text-slate-500 uppercase tracking-wide mb-2 block">One-line Description</label>
                  <input className="input-field" value={productDescription} onChange={(e) => setProductDescription(e.target.value)} placeholder="What it does and for whom" />
                </div>
              </div>

              {/* Tone Selector */}
              <div className="glass rounded-2xl p-5">
                <h2 className="heading-font text-base font-semibold text-white mb-3">Tone</h2>
                <div className="space-y-2">
                  {tones.map((t) => {
                    const cfg = toneConfig[t];
                    const active = tone === t;
                    return (
                      <button
                        key={t}
                        onClick={() => setTone(t)}
                        className={`w-full text-left px-4 py-3 rounded-xl border transition-all duration-200 ${active ? `${cfg.bg} ${cfg.border}` : "bg-white/[0.02] border-white/[0.06] hover:bg-white/[0.05]"}`}
                      >
                        <span className={`text-sm font-medium ${active ? "text-white" : "text-slate-400"}`}>{t}</span>
                        <span className="text-xs text-slate-600 ml-2">{t === "Professional" ? "Trusted & formal" : t === "Casual" ? "Warm & human" : "No fluff, just value"}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* CTA Buttons */}
              <div className="space-y-2">
                <button
                  className="btn-primary w-full flex items-center justify-center gap-2"
                  onClick={() => generate(tone)}
                  disabled={loading || !companyName || !painPoints || !outreachAngle || !productName || !productDescription}
                >
                  {loading ? (
                    <>
                      <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="rgba(255,255,255,0.3)" strokeWidth="3"/><path d="M12 2a10 10 0 0 1 10 10" stroke="white" strokeWidth="3" strokeLinecap="round"/></svg>
                      Crafting sequence...
                    </>
                  ) : (
                    <>✦ Generate Sequence</>
                  )}
                </button>

                {result && (
                  <div className="flex gap-2">
                    <button className="btn-ghost flex-1" onClick={() => generate(tone)} disabled={loading}>
                      ↻ Regenerate
                    </button>
                    <button
                      onClick={() => setSent((v) => !v)}
                      className={`flex-1 rounded-xl px-4 py-2.5 text-sm font-medium transition-all duration-200 ${sent ? "sent-badge text-white" : "unsent-badge text-slate-400 hover:text-white"}`}
                    >
                      {sent ? "✓ Sent" : "Mark Sent"}
                    </button>
                  </div>
                )}
              </div>

              {error && (
                <div className="rounded-xl border border-red-500/20 bg-red-500/8 px-4 py-3 text-sm text-red-400">
                  {error}
                </div>
              )}
            </div>

            {/* Right: Output Preview */}
            <div className="lg:col-span-3 space-y-4">
              {!result && !loading && (
                <div className="glass rounded-2xl p-12 flex flex-col items-center justify-center min-h-[480px] fade-in" style={{ animationDelay: "0.1s" }}>
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border border-cyan-500/20 flex items-center justify-center text-3xl mb-4">✉</div>
                  <h3 className="heading-font text-lg font-semibold text-white mb-2">Ready to forge outreach</h3>
                  <p className="text-slate-500 text-sm text-center max-w-xs">Fill in the target intelligence on the left and hit Generate to create a full multi-touch sequence.</p>
                  <div className="mt-6 flex gap-3 text-xs text-slate-600">
                    <span className="glass rounded-full px-3 py-1">Cold Email</span>
                    <span className="glass rounded-full px-3 py-1">LinkedIn DM</span>
                    <span className="glass rounded-full px-3 py-1">Follow-ups</span>
                  </div>
                </div>
              )}

              {loading && (
                <div className="glass rounded-2xl p-6 min-h-[480px] space-y-4 fade-in">
                  <div className="flex items-center gap-3 mb-6">
                    <svg className="animate-spin w-5 h-5 text-cyan-400" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="rgba(6,182,212,0.3)" strokeWidth="3"/><path d="M12 2a10 10 0 0 1 10 10" stroke="#22d3ee" strokeWidth="3" strokeLinecap="round"/></svg>
                    <span className="text-cyan-400 text-sm font-medium">AI crafting personalized sequence...</span>
                  </div>
                  {[80, 60, 95, 70, 55].map((w, i) => (
                    <div key={i} className={`h-4 rounded-full loading-shimmer`} style={{ width: `${w}%` }} />
                  ))}
                </div>
              )}

              {result && (
                <div className="space-y-4 fade-in">
                  {/* Score Banner */}
                  <div className="glass rounded-2xl p-5 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="relative">
                        <svg width="56" height="56" viewBox="0 0 56 56">
                          <circle cx="28" cy="28" r="22" fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="5"/>
                          <circle cx="28" cy="28" r="22" fill="none" stroke="url(#scoreGrad)" strokeWidth="5" strokeLinecap="round"
                            strokeDasharray={`${(result.personalization_score / 100) * 138} 138`}
                            strokeDashoffset="34.5"
                            transform="rotate(-90 28 28)"
                          />
                          <defs>
                            <linearGradient id="scoreGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                              <stop offset="0%" stopColor="#06b6d4"/>
                              <stop offset="100%" stopColor="#3b82f6"/>
                            </linearGradient>
                          </defs>
                          <text x="28" y="33" textAnchor="middle" fontSize="13" fontWeight="700" fill="white" fontFamily="Syne">{result.personalization_score}</text>
                        </svg>
                      </div>
                      <div>
                        <div className="text-xs text-slate-500 uppercase tracking-wide mb-1">Personalization Score</div>
                        <div className={`text-sm font-semibold ${scoreColor(result.personalization_score)}`}>
                          {result.personalization_score >= 80 ? "Highly Personalized" : result.personalization_score >= 60 ? "Moderately Tailored" : "Generic — Regenerate"}
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => setWhyOpen(!whyOpen)}
                      className="text-xs text-slate-500 hover:text-cyan-400 border border-white/8 hover:border-cyan-500/30 rounded-lg px-3 py-2 transition-all"
                    >
                      Why this works {whyOpen ? "▲" : "▼"}
                    </button>
                  </div>

                  {whyOpen && (
                    <div className="glass rounded-xl px-5 py-4 border-l-2 border-cyan-500/40 fade-in">
                      <p className="text-sm text-slate-300 leading-relaxed">{result.why_this_works}</p>
                    </div>
                  )}

                  {/* Tab Switcher */}
                  <div className="glass rounded-2xl p-2 flex gap-1.5">
                    {tabs.map((t) => (
                      <button
                        key={t}
                        onClick={() => setTab(t)}
                        className={`flex-1 rounded-xl px-2 py-2.5 text-xs font-medium transition-all duration-200 ${tab === t ? "tab-active" : "tab-inactive"}`}
                      >
                        <div>{tabIcons[t]}</div>
                        <div className="mt-0.5 hidden sm:block">{t.split(" ").slice(0,2).join(" ")}</div>
                      </button>
                    ))}
                  </div>

                  {/* Message Preview */}
                  <div className="glass rounded-2xl p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-white">{tab}</span>
                        <span className="text-xs text-slate-600 bg-white/5 rounded-full px-2 py-0.5">{currentContent.length} chars</span>
                      </div>
                      <button
                        onClick={handleCopy}
                        className={`text-xs px-3 py-1.5 rounded-lg border transition-all duration-200 ${copied ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-400" : "border-white/10 text-slate-500 hover:text-white hover:border-white/20"}`}
                      >
                        {copied ? "✓ Copied" : "Copy"}
                      </button>
                    </div>

                    <div
                      className="text-sm text-slate-300 leading-relaxed whitespace-pre-wrap rounded-xl p-4 min-h-[240px]"
                      style={{ background: "rgba(0,0,0,0.25)", border: "1px solid rgba(255,255,255,0.06)", fontFamily: "DM Sans, sans-serif" }}
                    >
                      {currentContent}
                    </div>
                  </div>

                  {/* All Tabs Quick Preview */}
                  <div className="grid grid-cols-2 gap-3">
                    {tabs.filter(t => t !== tab).map(t => {
                      const content = t === "Cold Email" ? `Subject: ${result.email.subject}\n\n${result.email.body}` : t === "LinkedIn DM" ? result.linkedin_dm : t === "Follow-up Day 3" ? result.follow_up_day3 : result.follow_up_day7;
                      return (
                        <button key={t} onClick={() => setTab(t)} className="glass glass-hover rounded-xl p-4 text-left">
                          <div className="text-xs text-slate-500 mb-1">{tabIcons[t]} {t}</div>
                          <div className="text-xs text-slate-400 line-clamp-2 leading-relaxed">{content.slice(0,80)}…</div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}